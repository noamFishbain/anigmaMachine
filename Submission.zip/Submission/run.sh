#!/bin/bash
java -cp ConsoleUI.jar:Logic.jar ui.Main